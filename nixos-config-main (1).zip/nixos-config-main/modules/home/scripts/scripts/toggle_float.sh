#!/usr/bin/env bash

hyprctl dispatch togglefloating
hyprctl dispatch resizeactive exact 1111 700
hyprctl dispatch centerwindow
