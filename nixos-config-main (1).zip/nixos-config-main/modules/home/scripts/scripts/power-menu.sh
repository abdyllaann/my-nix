#!/usr/bin/env bash

rofi -show p -modi p:'rofi-power-menu' -theme-str 'window {width: 10em; height: 15em;} listview {lines: 5;}'
